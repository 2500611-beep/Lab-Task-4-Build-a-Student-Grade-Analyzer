class Student {
  constructor(name, marks) {
    this.name = name;
    this.marks = marks;
  }

  getGrade() {
    if (this.marks >= 85) return 'A';
    if (this.marks >= 70) return 'B';
    if (this.marks >= 50) return 'C';
    return 'F';
  }
}

const students = [
  new Student('Ali', 78),
  new Student('Aisha', 92),
  new Student('Bilal', 41),
  new Student('Sara', 65),
  new Student('Zain', 48),
  new Student('Hana', 88)
];

const passingNames = students
  .filter(s => s.marks >= 50)
  .map(s => s.name);

const totalMarks = students.reduce((sum, s) => sum + s.marks, 0);
const classAverage = Math.round(totalMarks / students.length);

const sortedStudents = [...students].sort((a, b) => b.marks - a.marks);
const [topScorer] = sortedStudents;

console.log(`Passing students: ${passingNames.join(', ')}`);
console.log(`Class average: ${classAverage}`);
console.log(`Top scorer: ${topScorer.name} (${topScorer.marks})`);

students.forEach(s => {
  const status = s.marks >= 50 ? 'Pass' : 'Fail';
  console.log(`${s.name}: ${s.marks} -> ${status}`);
});


